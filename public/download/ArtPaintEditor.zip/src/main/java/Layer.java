import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.Serializable;

public class Layer implements Serializable {
    private String name;
    private boolean visible;
    private int order;
    private transient JPanel layerPanel;
    private transient JLabel nameLabel;
    private transient JCheckBox visibilityCheckbox;
    private transient JLabel thumbnailLabel;

    public Layer(String name, int order) {
        this.name = name;
        this.visible = true;
        this.order = order;
        createLayerPanel();
    }

    private void createLayerPanel() {
        layerPanel = new JPanel(new BorderLayout(5, 0));
        layerPanel.setBackground(Color.LIGHT_GRAY);
        layerPanel.setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY));
        layerPanel.setPreferredSize(new Dimension(200, 60));

        // Thumbnail
        thumbnailLabel = new JLabel();
        thumbnailLabel.setPreferredSize(new Dimension(40, 40));
        thumbnailLabel.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        updateThumbnail(); // Placeholder thumbnail

        // Visibility checkbox
        visibilityCheckbox = new JCheckBox("", visible);
        visibilityCheckbox.setBackground(Color.LIGHT_GRAY);
        visibilityCheckbox.addActionListener(e -> setVisible(visibilityCheckbox.isSelected()));

        // Layer name label
        nameLabel = new JLabel(name);
        nameLabel.setBorder(BorderFactory.createEmptyBorder(0, 5, 0, 0));

        JPanel infoPanel = new JPanel(new BorderLayout());
        infoPanel.setBackground(Color.LIGHT_GRAY);
        infoPanel.add(visibilityCheckbox, BorderLayout.WEST);
        infoPanel.add(nameLabel, BorderLayout.CENTER);

        JPanel contentPanel = new JPanel(new BorderLayout(5, 0));
        contentPanel.setBackground(Color.LIGHT_GRAY);
        contentPanel.add(thumbnailLabel, BorderLayout.WEST);
        contentPanel.add(infoPanel, BorderLayout.CENTER);

        layerPanel.add(contentPanel, BorderLayout.CENTER);
    }

    public void updateThumbnail(BufferedImage thumbnail) {
        if (thumbnailLabel != null && thumbnail != null) {
            ImageIcon icon = new ImageIcon(thumbnail.getScaledInstance(40, 40, Image.SCALE_SMOOTH));
            thumbnailLabel.setIcon(icon);
        }
    }

    private void updateThumbnail() {
        // Create placeholder thumbnail
        BufferedImage placeholder = new BufferedImage(40, 40, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = placeholder.createGraphics();
        g2d.setColor(Color.WHITE);
        g2d.fillRect(0, 0, 40, 40);
        g2d.setColor(Color.LIGHT_GRAY);
        g2d.drawRect(0, 0, 39, 39);
        g2d.dispose();

        if (thumbnailLabel != null) {
            thumbnailLabel.setIcon(new ImageIcon(placeholder));
        }
    }

    public JPanel getLayerPanel() {
        if (layerPanel == null) {
            createLayerPanel();
        }
        return layerPanel;
    }

    public String getName() { return name; }
    public void setName(String name) {
        this.name = name;
        if (nameLabel != null) nameLabel.setText(name);
    }

    public boolean isVisible() { return visible; }
    public void setVisible(boolean visible) {
        this.visible = visible;
        if (visibilityCheckbox != null) visibilityCheckbox.setSelected(visible);
    }

    public int getOrder() { return order; }
    public void setOrder(int order) { this.order = order; }

    @Override
    public String toString() {
        return name + (visible ? " (Visible)" : " (Hidden)");
    }
}
import java.awt.*;

public abstract class Shape {
    protected Color shapeColor;
    protected int strokeSize;

    public Shape(Color color, int strokeSize) {
        this.shapeColor = color;
        this.strokeSize = strokeSize;
    }

    public abstract void draw(Graphics2D g2d);

    public static class LineShape extends Shape {
        private int x1, y1, x2, y2;

        public LineShape(int x1, int y1, int x2, int y2, Color color, int strokeSize) {
            super(color, strokeSize);
            this.x1 = x1;
            this.y1 = y1;
            this.x2 = x2;
            this.y2 = y2;
        }

        @Override
        public void draw(Graphics2D g2d) {
            g2d.setColor(shapeColor);
            g2d.setStroke(new BasicStroke(strokeSize));
            g2d.drawLine(x1, y1, x2, y2);
        }
    }

    public static class SquareShape extends Shape {
        private int x, y, size;

        public SquareShape(int x, int y, int size, Color color, int strokeSize) {
            super(color, strokeSize);
            this.x = x;
            this.y = y;
            this.size = size;
        }

        @Override
        public void draw(Graphics2D g2d) {
            g2d.setColor(shapeColor);
            g2d.setStroke(new BasicStroke(strokeSize));
            g2d.drawRect(x, y, size, size);
        }
    }

    public static class CircleShape extends Shape {
        private int x, y, diameter;

        public CircleShape(int x, int y, int diameter, Color color, int strokeSize) {
            super(color, strokeSize);
            this.x = x;
            this.y = y;
            this.diameter = diameter;
        }

        @Override
        public void draw(Graphics2D g2d) {
            g2d.setColor(shapeColor);
            g2d.setStroke(new BasicStroke(strokeSize));
            g2d.drawOval(x, y, diameter, diameter);
        }
    }
}
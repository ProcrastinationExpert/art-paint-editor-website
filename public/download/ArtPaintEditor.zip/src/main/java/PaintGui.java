import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;

public class PaintGui extends JFrame {
    private Canvas canvas;
    private JLabel brushSizeLabel;
    private JLabel opacityLabel;
    private JPanel layersPanel;
    private JScrollPane layersScrollPane;
    private HSLColorPicker colorPicker;
    private Timer thumbnailUpdateTimer;

    public PaintGui(){
        super("Paint GUI");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setPreferredSize(new Dimension(1500, 1000));
        pack();
        setLocationRelativeTo(null);

        addGuiComponents();

        // Timer to update layer thumbnails
        thumbnailUpdateTimer = new Timer(500, e -> updateLayerThumbnails());
        thumbnailUpdateTimer.setRepeats(false);
    }

    private void addGuiComponents(){
        // Main container with BorderLayout
        JPanel mainPanel = new JPanel(new BorderLayout());

        // Left panel for canvas and controls
        JPanel leftPanel = new JPanel();
        SpringLayout springLayout = new SpringLayout();
        leftPanel.setLayout(springLayout);

        // 1. Canvas
        canvas = new Canvas(1000, 900);
        leftPanel.add(canvas);
        springLayout.putConstraint(SpringLayout.NORTH, canvas, 50, SpringLayout.NORTH, leftPanel);
        springLayout.putConstraint(SpringLayout.WEST, canvas, 25, SpringLayout.WEST, leftPanel);

        // Top controls
        addTopControls(leftPanel, springLayout);

        // Right panel for tools and layers
        JPanel rightPanel = createRightPanel();

        // Add panels to main container
        mainPanel.add(leftPanel, BorderLayout.CENTER);
        mainPanel.add(rightPanel, BorderLayout.EAST);

        this.getContentPane().add(mainPanel);
    }

    private void addTopControls(JPanel panel, SpringLayout layout) {
        // Color Chooser (fallback)
        JButton chooseColorButton = new JButton("Choose Color");
        chooseColorButton.addActionListener(e -> {
            Color c = JColorChooser.showDialog(null, "Select a color", Color.BLACK);
            chooseColorButton.setBackground(c);
            canvas.setColor(c);
        });
        panel.add(chooseColorButton);
        layout.putConstraint(SpringLayout.NORTH, chooseColorButton, 10, SpringLayout.NORTH, panel);
        layout.putConstraint(SpringLayout.WEST, chooseColorButton, 25, SpringLayout.WEST, panel);

        // Reset Button
        JButton resetButton = new JButton("Reset");
        resetButton.addActionListener(e -> canvas.resetCanvas());
        panel.add(resetButton);
        layout.putConstraint(SpringLayout.NORTH, resetButton, 10, SpringLayout.NORTH, panel);
        layout.putConstraint(SpringLayout.WEST, resetButton, 150, SpringLayout.WEST, panel);

        // Draw Mode Button
        JButton drawButton = new JButton("Draw Mode");
        drawButton.addActionListener(e -> canvas.setDrawingMode(Canvas.Mode.DRAW));
        panel.add(drawButton);
        layout.putConstraint(SpringLayout.NORTH, drawButton, 10, SpringLayout.NORTH, panel);
        layout.putConstraint(SpringLayout.WEST, drawButton, 225, SpringLayout.WEST, panel);

        // Line Shape Button
        JButton lineButton = new JButton("Line Shape");
        lineButton.addActionListener(e -> canvas.setDrawingMode(Canvas.Mode.LINE));
        panel.add(lineButton);
        layout.putConstraint(SpringLayout.NORTH, lineButton, 10, SpringLayout.NORTH, panel);
        layout.putConstraint(SpringLayout.WEST, lineButton, 325, SpringLayout.WEST, panel);

        // Square Shape Button
        JButton squareButton = new JButton("Square Shape");
        squareButton.addActionListener(e -> canvas.setDrawingMode(Canvas.Mode.SQUARE));
        panel.add(squareButton);
        layout.putConstraint(SpringLayout.NORTH, squareButton, 10, SpringLayout.NORTH, panel);
        layout.putConstraint(SpringLayout.WEST, squareButton, 425, SpringLayout.WEST, panel);

        // Circle Shape Button
        JButton circleButton = new JButton("Circle Shape");
        circleButton.addActionListener(e -> canvas.setDrawingMode(Canvas.Mode.CIRCLE));
        panel.add(circleButton);
        layout.putConstraint(SpringLayout.NORTH, circleButton, 10, SpringLayout.NORTH, panel);
        layout.putConstraint(SpringLayout.WEST, circleButton, 540, SpringLayout.WEST, panel);

        // Undo Button
        JButton undoButton = new JButton("Undo");
        undoButton.addActionListener(e -> canvas.undo());
        panel.add(undoButton);
        layout.putConstraint(SpringLayout.NORTH, undoButton, 10, SpringLayout.NORTH, panel);
        layout.putConstraint(SpringLayout.WEST, undoButton, 650, SpringLayout.WEST, panel);

        // Redo Button
        JButton redoButton = new JButton("Redo");
        redoButton.addActionListener(e -> canvas.redo());
        panel.add(redoButton);
        layout.putConstraint(SpringLayout.NORTH, redoButton, 10, SpringLayout.NORTH, panel);
        layout.putConstraint(SpringLayout.WEST, redoButton, 720, SpringLayout.WEST, panel);
    }

    private JPanel createRightPanel() {
        JPanel rightPanel = new JPanel();
        rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.Y_AXIS));
        rightPanel.setPreferredSize(new Dimension(320, 1000));
        rightPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // HSL Color Picker
        HSLColorPicker colorPicker = new HSLColorPicker();
        colorPicker.setColorSelectionListener(new HSLColorPicker.ColorSelectionListener() {
            @Override
            public void colorSelected(Color color) {
                canvas.setColor(color);
                updateLayerThumbnails(); // Real-time thumbnail updates
            }

            @Override
            public void brushSizeChanged(int size) {
                canvas.setBrushSize(size);
                updateLayerThumbnails(); // Real-time thumbnail updates
            }

            @Override
            public void opacityChanged(float opacity) {
                canvas.setOpacity(opacity);
                updateLayerThumbnails(); // Real-time thumbnail updates
            }

            @Override
            public void brushTypeChanged(int brushType) {
                // Map your brush types to canvas brush types
                Canvas.BrushType[] brushTypes = {
                        Canvas.BrushType.SOFT_ROUND,
                        Canvas.BrushType.HARD_ROUND,
                        Canvas.BrushType.SPRAY,
                        Canvas.BrushType.SQUARE
                };
                if (brushType >= 0 && brushType < brushTypes.length) {
                    canvas.setBrushType(brushTypes[brushType]);
                    updateLayerThumbnails(); // Real-time thumbnail updates
                }
            }
        });

        rightPanel.add(colorPicker);

        // Layers Panel
        rightPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        rightPanel.add(createLayersPanel());

        return rightPanel;
    }

    private JPanel createBrushSettingsPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createTitledBorder("Brush Settings"));

        // Brush Size Slider
        brushSizeLabel = new JLabel("Size: 8");
        JSlider sizeSlider = new JSlider(1, 50, 8);
        sizeSlider.setPreferredSize(new Dimension(200, 40));
        sizeSlider.addChangeListener(e -> {
            int size = sizeSlider.getValue();
            brushSizeLabel.setText("Size: " + size);
            canvas.setBrushSize(size);
            thumbnailUpdateTimer.restart();
        });

        // Opacity Slider
        opacityLabel = new JLabel("Opacity: 100%");
        JSlider opacitySlider = new JSlider(0, 100, 100);
        opacitySlider.setPreferredSize(new Dimension(200, 40));
        opacitySlider.addChangeListener(e -> {
            float opacity = opacitySlider.getValue() / 100.0f;
            opacityLabel.setText("Opacity: " + opacitySlider.getValue() + "%");
            canvas.setOpacity(opacity);
            thumbnailUpdateTimer.restart();
        });

        // Brush Type Selection
        JPanel brushTypePanel = new JPanel(new GridLayout(2, 2, 5, 5));
        brushTypePanel.setBorder(BorderFactory.createTitledBorder("Brush Types"));

        String[] brushNames = {"Soft Round", "Hard Round", "Spray", "Square"};
        Canvas.BrushType[] brushTypes = {
                Canvas.BrushType.SOFT_ROUND,
                Canvas.BrushType.HARD_ROUND,
                Canvas.BrushType.SPRAY,
                Canvas.BrushType.SQUARE
        };

        ButtonGroup brushGroup = new ButtonGroup();
        for (int i = 0; i < brushNames.length; i++) {
            JRadioButton brushButton = new JRadioButton(brushNames[i]);
            brushButton.setActionCommand(brushTypes[i].name());
            brushButton.addActionListener(e -> {
                canvas.setBrushType(Canvas.BrushType.valueOf(brushButton.getActionCommand()));
                thumbnailUpdateTimer.restart();
            });
            if (i == 0) brushButton.setSelected(true);
            brushGroup.add(brushButton);
            brushTypePanel.add(brushButton);
        }

        panel.add(brushSizeLabel);
        panel.add(sizeSlider);
        panel.add(Box.createRigidArea(new Dimension(0, 5)));
        panel.add(opacityLabel);
        panel.add(opacitySlider);
        panel.add(Box.createRigidArea(new Dimension(0, 10)));
        panel.add(brushTypePanel);

        return panel;
    }

    private JPanel createLayersPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createTitledBorder("Layers"));

        // Layers control buttons
        JPanel layersControlPanel = new JPanel(new FlowLayout());
        JButton addLayerButton = new JButton("+ Add Layer");
        JButton removeLayerButton = new JButton("- Remove Layer");

        addLayerButton.addActionListener(e -> {
            String layerName = JOptionPane.showInputDialog(this, "Enter layer name:", "Layer " + (canvas.getLayers().size() + 1));
            if (layerName != null && !layerName.trim().isEmpty()) {
                canvas.createLayer(layerName);
                updateLayersPanel();
            }
        });

        removeLayerButton.addActionListener(e -> {
            Layer currentLayer = canvas.getCurrentLayer();
            if (currentLayer != null) {
                int confirm = JOptionPane.showConfirmDialog(this,
                        "Delete layer '" + currentLayer.getName() + "'?", "Confirm Delete",
                        JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    canvas.removeLayer(currentLayer);
                    updateLayersPanel();
                }
            }
        });

        layersControlPanel.add(addLayerButton);
        layersControlPanel.add(removeLayerButton);
        panel.add(layersControlPanel, BorderLayout.NORTH);

        // Layers list panel - FIXED HEIGHT CONTAINER
        layersPanel = new JPanel();
        layersPanel.setLayout(new BoxLayout(layersPanel, BoxLayout.Y_AXIS));
        updateLayersPanel();

        // Create a fixed-size scroll pane
        JScrollPane fixedScrollPane = new JScrollPane(layersPanel);
        fixedScrollPane.setPreferredSize(new Dimension(280, 300)); // Fixed height
        fixedScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        fixedScrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        panel.add(fixedScrollPane, BorderLayout.CENTER);

        return panel;
    }

    // New method to create consistent layer item panels
    private JPanel createLayerItemPanel(Layer layer, int layerIndex) {
        JPanel layerPanel = new JPanel(new BorderLayout(5, 0));
        layerPanel.setPreferredSize(new Dimension(260, 60)); // Fixed height for each layer
        layerPanel.setMaximumSize(new Dimension(260, 60)); // Fixed maximum height
        layerPanel.setBackground(Color.LIGHT_GRAY);
        layerPanel.setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY));

        // Thumbnail
        JLabel thumbnailLabel = new JLabel();
        thumbnailLabel.setPreferredSize(new Dimension(40, 40));
        thumbnailLabel.setBorder(BorderFactory.createLineBorder(Color.GRAY));

        // Update thumbnail
        BufferedImage thumbnail = canvas.generateLayerThumbnail(layerIndex, 40, 40);
        if (thumbnail != null) {
            ImageIcon icon = new ImageIcon(thumbnail.getScaledInstance(40, 40, Image.SCALE_SMOOTH));
            thumbnailLabel.setIcon(icon);
        }

        // Visibility checkbox with real-time updates
        JCheckBox visibilityCheckbox = new JCheckBox("", layer.isVisible());
        visibilityCheckbox.setBackground(Color.LIGHT_GRAY);
        visibilityCheckbox.addActionListener(e -> {
            layer.setVisible(visibilityCheckbox.isSelected());
            canvas.repaint(); // Real-time update when visibility changes
            updateLayerThumbnails(); // Update thumbnails to reflect changes
        });

        // Layer name
        JLabel nameLabel = new JLabel(layer.getName());
        nameLabel.setBorder(BorderFactory.createEmptyBorder(0, 5, 0, 0));

        // Info panel
        JPanel infoPanel = new JPanel(new BorderLayout());
        infoPanel.setBackground(Color.LIGHT_GRAY);
        infoPanel.add(visibilityCheckbox, BorderLayout.WEST);
        infoPanel.add(nameLabel, BorderLayout.CENTER);

        // Content panel
        JPanel contentPanel = new JPanel(new BorderLayout(5, 0));
        contentPanel.setBackground(Color.LIGHT_GRAY);
        contentPanel.add(thumbnailLabel, BorderLayout.WEST);
        contentPanel.add(infoPanel, BorderLayout.CENTER);

        layerPanel.add(contentPanel, BorderLayout.CENTER);

        // Click to select layer
        layerPanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                canvas.setCurrentLayer(layer);
                highlightSelectedLayer(layer);
                canvas.repaint(); // Real-time update when layer changes
            }
        });

        return layerPanel;
    }

    private void updateLayersPanel() {
        layersPanel.removeAll();

        java.util.List<Layer> layers = canvas.getLayers();
        for (int i = 0; i < layers.size(); i++) {
            Layer layer = layers.get(i);
            JPanel layerPanel = createLayerItemPanel(layer, i);
            layersPanel.add(layerPanel);
            layersPanel.add(Box.createRigidArea(new Dimension(0, 5)));
        }

        // Add glue to push content to top when there are few layers
        if (layers.size() < 4) {
            layersPanel.add(Box.createVerticalGlue());
        }

        // Highlight current layer
        highlightSelectedLayer(canvas.getCurrentLayer());

        layersPanel.revalidate();
        layersPanel.repaint();

        // Update thumbnails
        updateLayerThumbnails();
    }

    private void updateLayerThumbnails() {
        java.util.List<Layer> layers = canvas.getLayers();
        for (int i = 0; i < layers.size(); i++) {
            Layer layer = layers.get(i);
            BufferedImage thumbnail = canvas.generateLayerThumbnail(i, 40, 40);
            if (thumbnail != null) {
                layer.updateThumbnail(thumbnail);
            }
        }
        layersPanel.repaint();
    }

    private void highlightSelectedLayer(Layer selectedLayer) {
        for (int i = 0; i < layersPanel.getComponentCount(); i++) {
            Component comp = layersPanel.getComponent(i);
            if (comp instanceof JPanel) {
                JPanel layerPanel = (JPanel) comp;
                Layer layer = findLayerByPanel(layerPanel);
                if (layer == selectedLayer) {
                    layerPanel.setBackground(Color.YELLOW);
                    layerPanel.setBorder(BorderFactory.createLineBorder(Color.RED, 2));
                } else {
                    layerPanel.setBackground(Color.LIGHT_GRAY);
                    layerPanel.setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY));
                }
            }
        }
    }



    private Layer findLayerByPanel(JPanel panel) {
        for (Layer layer : canvas.getLayers()) {
            if (layer.getLayerPanel() == panel) {
                return layer;
            }
        }
        return null;
    }

    // Simplified transfer handler for layers
    class LayerTransferHandler extends TransferHandler {
        private Layer layer;
        private int originalIndex;

        public LayerTransferHandler(Layer layer, int index) {
            this.layer = layer;
            this.originalIndex = index;
        }

        @Override
        public int getSourceActions(JComponent c) {
            return MOVE;
        }
    }
}
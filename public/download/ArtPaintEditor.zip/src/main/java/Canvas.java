import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.Stack;
import java.awt.image.BufferedImage;

public class Canvas extends JPanel {
    enum Mode {
        DRAW,
        LINE,
        CIRCLE,
        SQUARE
    }

    enum BrushType {
        SOFT_ROUND,
        HARD_ROUND,
        SPRAY,
        SQUARE
    }

    // Brush properties
    private int brushSize = 8;
    private float opacity = 1.0f;
    private BrushType currentBrush = BrushType.SOFT_ROUND;

    // Drawing Mode
    private Mode DrawingMode = Mode.DRAW;

    // Layer system
    private List<Layer> layers;
    private Layer currentLayer;
    private List<List<Drawable>> layerDrawables;

    // For undo/redo functionality
    private Stack<UndoAction> undoStack;
    private Stack<UndoAction> redoStack;

    // used to draw a line between points
    private List<ColorPoint> currentPath;

    // color of the dots
    private Color color;

    // For shape drawing
    private int startX, startY;
    private int endX, endY;
    private boolean drawingShape = false;
    private Shape previewShape;

    // Interface for all drawable objects
    private interface Drawable {
        void draw(Graphics2D g2d);
        int getLayerIndex();
        BufferedImage getThumbnail(int width, int height);
    }

    // Undo action interface
    private interface UndoAction {
        void undo();
        void redo();
    }

    public Canvas(int targetWidth, int targetHeight){
        super();
        setPreferredSize(new Dimension(targetWidth, targetHeight));
        setOpaque(true);
        setBackground(Color.WHITE);
        setBorder(BorderFactory.createLineBorder(Color.BLACK));

        // init vars
        layers = new ArrayList<>();
        layerDrawables = new ArrayList<>();
        undoStack = new Stack<>();
        redoStack = new Stack<>();
        color = Color.BLACK;

        // Create default layer
        createLayer("Layer 1");

        MouseAdapter ma = new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                if (currentLayer == null || !currentLayer.isVisible()) return;

                // get current mouse location
                startX = e.getX();
                startY = e.getY();

                if (DrawingMode == Mode.DRAW) {
                    // start current path
                    currentPath = new ArrayList<>();
                    currentPath.add(new ColorPoint(startX, startY, color, brushSize, opacity));

                    // Create preview immediately
                    repaint();
                } else {
                    drawingShape = true;
                    endX = startX;
                    endY = startY;
                    previewShape = createShape(startX, startY, endX, endY);
                }
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                if (currentLayer == null || !currentLayer.isVisible()) return;

                if (DrawingMode == Mode.DRAW && currentPath != null && !currentPath.isEmpty()) {
                    // Create final path and add to drawables
                    final List<ColorPoint> finalPath = new ArrayList<>(currentPath);
                    int layerIndex = layers.indexOf(currentLayer);
                    PathDrawable pathDrawable = new PathDrawable(finalPath, color, brushSize, opacity, layerIndex, currentBrush);
                    layerDrawables.get(layerIndex).add(pathDrawable);

                    // Store undo action
                    undoStack.push(new AddDrawableAction(layerIndex, pathDrawable));
                    redoStack.clear();

                    currentPath = null;
                    repaint();
                } else if (drawingShape && previewShape != null) {
                    // Finalize the shape
                    endX = e.getX();
                    endY = e.getY();

                    // Create final shape
                    Shape finalShape = createShape(startX, startY, endX, endY);
                    if (finalShape != null) {
                        int layerIndex = layers.indexOf(currentLayer);
                        ShapeDrawable shapeDrawable = new ShapeDrawable(finalShape, layerIndex);
                        layerDrawables.get(layerIndex).add(shapeDrawable);

                        // Store undo action
                        undoStack.push(new AddDrawableAction(layerIndex, shapeDrawable));
                        redoStack.clear();
                    }

                    drawingShape = false;
                    previewShape = null;
                    repaint();
                }
            }

            @Override
            public void mouseDragged(MouseEvent e) {
                if (currentLayer == null || !currentLayer.isVisible()) return;

                if (DrawingMode == Mode.DRAW && currentPath != null) {
                    // get current location
                    int x = e.getX();
                    int y = e.getY();

                    // add the new point to the path
                    ColorPoint nextPoint = new ColorPoint(x, y, color, brushSize, opacity);
                    currentPath.add(nextPoint);

                    repaint();
                } else if (drawingShape) {
                    // Update preview shape while dragging
                    endX = e.getX();
                    endY = e.getY();
                    previewShape = createShape(startX, startY, endX, endY);
                    repaint();
                }
            }
        };

        addMouseListener(ma);
        addMouseMotionListener(ma);
    }

    // Brush management
    public void setBrushSize(int size) {
        this.brushSize = size;
    }

    public int getBrushSize() {
        return brushSize;
    }

    public void setOpacity(float opacity) {
        this.opacity = opacity;
    }

    public float getOpacity() {
        return opacity;
    }

    public void setBrushType(BrushType brushType) {
        this.currentBrush = brushType;
    }

    public BrushType getBrushType() {
        return currentBrush;
    }

    // Layer management methods
    public void createLayer(String name) {
        Layer newLayer = new Layer(name, layers.size());
        layers.add(newLayer);
        layerDrawables.add(new ArrayList<>());
        setCurrentLayer(newLayer);
    }

    public void setCurrentLayer(Layer layer) {
        this.currentLayer = layer;
    }

    public Layer getCurrentLayer() {
        return currentLayer;
    }

    public List<Layer> getLayers() {
        return new ArrayList<>(layers);
    }

    public void removeLayer(Layer layer) {
        int index = layers.indexOf(layer);
        if (index != -1) {
            layers.remove(index);
            layerDrawables.remove(index);
            if (layers.isEmpty()) {
                createLayer("Layer 1");
            } else {
                setCurrentLayer(layers.get(0));
            }
            repaint();
        }
    }

    public void moveLayer(int fromIndex, int toIndex) {
        if (fromIndex >= 0 && fromIndex < layers.size() && toIndex >= 0 && toIndex < layers.size()) {
            Layer layer = layers.remove(fromIndex);
            List<Drawable> drawables = layerDrawables.remove(fromIndex);

            layers.add(toIndex, layer);
            layerDrawables.add(toIndex, drawables);

            // Update layer orders
            for (int i = 0; i < layers.size(); i++) {
                layers.get(i).setOrder(i);
            }
            repaint();
        }
    }

    // Generate thumbnail for a layer
    public BufferedImage generateLayerThumbnail(int layerIndex, int width, int height) {
        if (layerIndex < 0 || layerIndex >= layerDrawables.size()) {
            return null;
        }

        BufferedImage thumbnail = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = thumbnail.createGraphics();

        // Set white background
        g2d.setColor(Color.WHITE);
        g2d.fillRect(0, 0, width, height);

        // Enable anti-aliasing
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Scale and draw layer content
        double scaleX = (double) width / getWidth();
        double scaleY = (double) height / getHeight();
        g2d.scale(scaleX, scaleY);

        for (Drawable drawable : layerDrawables.get(layerIndex)) {
            drawable.draw(g2d);
        }

        g2d.dispose();
        return thumbnail;
    }

    private Shape createShape(int startX, int startY, int endX, int endY) {
        // Create shape with current color and brush size
        Color shapeColor = new Color(color.getRed(), color.getGreen(), color.getBlue(), (int)(opacity * 255));

        switch (DrawingMode) {
            case LINE:
                return new Shape.LineShape(startX, startY, endX, endY, shapeColor, brushSize);
            case SQUARE:
                int squareSize = Math.min(Math.abs(endX - startX), Math.abs(endY - startY));
                int squareX = startX;
                int squareY = startY;

                if (endX < startX) squareX = startX - squareSize;
                if (endY < startY) squareY = startY - squareSize;

                return new Shape.SquareShape(squareX, squareY, squareSize, shapeColor, brushSize);
            case CIRCLE:
                int radius = (int) Math.sqrt(Math.pow(endX - startX, 2) + Math.pow(endY - startY, 2));
                int circleX = startX - radius;
                int circleY = startY - radius;
                return new Shape.CircleShape(circleX, circleY, radius * 2, shapeColor, brushSize);
            default:
                return null;
        }
    }

    // Inner class for path drawable with brush support
    private class PathDrawable implements Drawable {
        private List<ColorPoint> path;
        private Color pathColor;
        private int pathStrokeSize;
        private float pathOpacity;
        private int layerIndex;
        private BrushType brushType;

        public PathDrawable(List<ColorPoint> path, Color color, int strokeSize, float opacity, int layerIndex, BrushType brushType) {
            this.path = new ArrayList<>(path);
            this.pathColor = new Color(color.getRed(), color.getGreen(), color.getBlue(), (int)(opacity * 255));
            this.pathStrokeSize = strokeSize;
            this.pathOpacity = opacity;
            this.layerIndex = layerIndex;
            this.brushType = brushType;
        }

        @Override
        public void draw(Graphics2D g2d) {
            if (path.isEmpty() || layerIndex >= layers.size() || !layers.get(layerIndex).isVisible()) return;

            g2d.setColor(pathColor);

            switch (brushType) {
                case SOFT_ROUND:
                    g2d.setStroke(new BasicStroke(pathStrokeSize, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                    drawSmoothPath(g2d);
                    break;
                case HARD_ROUND:
                    g2d.setStroke(new BasicStroke(pathStrokeSize, BasicStroke.CAP_ROUND, BasicStroke.JOIN_MITER));
                    drawSmoothPath(g2d);
                    break;
                case SPRAY:
                    drawSprayPath(g2d);
                    break;
                case SQUARE:
                    g2d.setStroke(new BasicStroke(pathStrokeSize, BasicStroke.CAP_SQUARE, BasicStroke.JOIN_MITER));
                    drawSmoothPath(g2d);
                    break;
            }
        }

        private void drawSmoothPath(Graphics2D g2d) {
            if (path.size() == 1) {
                ColorPoint point = path.get(0);
                int radius = pathStrokeSize / 2;
                g2d.fillOval(point.getX() - radius, point.getY() - radius, pathStrokeSize, pathStrokeSize);
                return;
            }

            for (int i = 0; i < path.size() - 1; i++) {
                ColorPoint from = path.get(i);
                ColorPoint to = path.get(i + 1);
                g2d.drawLine(from.getX(), from.getY(), to.getX(), to.getY());
            }
        }

        private void drawSprayPath(Graphics2D g2d) {
            int density = pathStrokeSize / 2 + 2;
            for (ColorPoint point : path) {
                for (int i = 0; i < density; i++) {
                    int offsetX = (int)(Math.random() * pathStrokeSize) - pathStrokeSize/2;
                    int offsetY = (int)(Math.random() * pathStrokeSize) - pathStrokeSize/2;
                    int size = (int)(Math.random() * pathStrokeSize/3) + 1;
                    g2d.fillOval(point.getX() + offsetX, point.getY() + offsetY, size, size);
                }
            }
        }

        @Override
        public int getLayerIndex() {
            return layerIndex;
        }

        @Override
        public BufferedImage getThumbnail(int width, int height) {
            BufferedImage thumb = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
            Graphics2D g2d = thumb.createGraphics();
            draw(g2d);
            g2d.dispose();
            return thumb;
        }
    }

    // Inner class for shape drawable
    private class ShapeDrawable implements Drawable {
        private Shape shape;
        private int layerIndex;

        public ShapeDrawable(Shape shape, int layerIndex) {
            this.shape = shape;
            this.layerIndex = layerIndex;
        }

        @Override
        public void draw(Graphics2D g2d) {
            if (layerIndex >= layers.size() || !layers.get(layerIndex).isVisible()) return;
            shape.draw(g2d);
        }

        @Override
        public int getLayerIndex() {
            return layerIndex;
        }

        @Override
        public BufferedImage getThumbnail(int width, int height) {
            BufferedImage thumb = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
            Graphics2D g2d = thumb.createGraphics();
            draw(g2d);
            g2d.dispose();
            return thumb;
        }
    }

    // Undo action for adding drawables
    private class AddDrawableAction implements UndoAction {
        private int layerIndex;
        private Drawable drawable;

        public AddDrawableAction(int layerIndex, Drawable drawable) {
            this.layerIndex = layerIndex;
            this.drawable = drawable;
        }

        @Override
        public void undo() {
            if (layerIndex < layerDrawables.size()) {
                layerDrawables.get(layerIndex).remove(drawable);
            }
        }

        @Override
        public void redo() {
            if (layerIndex < layerDrawables.size()) {
                layerDrawables.get(layerIndex).add(drawable);
            }
        }
    }

    public void setDrawingMode(Mode mode) {
        this.DrawingMode = mode;
    }

    public Mode getDrawingMode() {
        return DrawingMode;
    }

    public void setColor(Color color){
        this.color = color;
    }

    public void resetCanvas(){
        // Store undo action for reset
        final List<List<Drawable>> savedDrawables = new ArrayList<>();
        for (List<Drawable> drawableList : layerDrawables) {
            savedDrawables.add(new ArrayList<>(drawableList));
        }

        if (!savedDrawables.isEmpty()) {
            undoStack.push(new UndoAction() {
                @Override
                public void undo() {
                    for (int i = 0; i < layerDrawables.size() && i < savedDrawables.size(); i++) {
                        layerDrawables.set(i, new ArrayList<>(savedDrawables.get(i)));
                    }
                }

                @Override
                public void redo() {
                    for (int i = 0; i < layerDrawables.size(); i++) {
                        layerDrawables.set(i, new ArrayList<>());
                    }
                }
            });
            redoStack.clear();
        }

        // reset the drawables
        for (List<Drawable> drawableList : layerDrawables) {
            drawableList.clear();
        }
        currentPath = null;
        drawingShape = false;
        previewShape = null;

        repaint();
    }

    public void undo() {
        if (!undoStack.isEmpty()) {
            UndoAction action = undoStack.pop();
            action.undo();
            redoStack.push(action);
            repaint();
        }
    }

    public void redo() {
        if (!redoStack.isEmpty()) {
            UndoAction action = redoStack.pop();
            action.redo();
            undoStack.push(action);
            repaint();
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;

        // Enable anti-aliasing for smoother graphics
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);

        // Draw all layers from bottom to top
        for (int i = 0; i < layers.size(); i++) {
            if (layers.get(i).isVisible()) {
                for (Drawable drawable : layerDrawables.get(i)) {
                    drawable.draw(g2d);
                }
            }
        }

        // Draw current path preview (for draw mode)
        if (currentPath != null && !currentPath.isEmpty() && currentLayer != null && currentLayer.isVisible()) {
            g2d.setColor(new Color(color.getRed(), color.getGreen(), color.getBlue(), (int)(opacity * 255)));

            switch (currentBrush) {
                case SOFT_ROUND:
                    g2d.setStroke(new BasicStroke(brushSize, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                    drawPreviewPath(g2d);
                    break;
                case HARD_ROUND:
                    g2d.setStroke(new BasicStroke(brushSize, BasicStroke.CAP_ROUND, BasicStroke.JOIN_MITER));
                    drawPreviewPath(g2d);
                    break;
                case SPRAY:
                    drawPreviewSpray(g2d);
                    break;
                case SQUARE:
                    g2d.setStroke(new BasicStroke(brushSize, BasicStroke.CAP_SQUARE, BasicStroke.JOIN_MITER));
                    drawPreviewPath(g2d);
                    break;
            }
        }

        // Draw preview of current shape being drawn
        if (drawingShape && previewShape != null && currentLayer != null && currentLayer.isVisible()) {
            g2d.setColor(new Color(color.getRed(), color.getGreen(), color.getBlue(), (int)(opacity * 255)));
            g2d.setStroke(new BasicStroke(brushSize));
            previewShape.draw(g2d);
        }
    }

    private void drawPreviewPath(Graphics2D g2d) {
        if (currentPath.size() == 1) {
            ColorPoint point = currentPath.get(0);
            int radius = brushSize / 2;
            g2d.fillOval(point.getX() - radius, point.getY() - radius, brushSize, brushSize);
        } else {
            for (int i = 0; i < currentPath.size() - 1; i++) {
                ColorPoint from = currentPath.get(i);
                ColorPoint to = currentPath.get(i + 1);
                g2d.drawLine(from.getX(), from.getY(), to.getX(), to.getY());
            }
        }
    }

    private void drawPreviewSpray(Graphics2D g2d) {
        int density = brushSize / 2 + 2;
        for (ColorPoint point : currentPath) {
            for (int i = 0; i < density; i++) {
                int offsetX = (int)(Math.random() * brushSize) - brushSize/2;
                int offsetY = (int)(Math.random() * brushSize) - brushSize/2;
                int size = (int)(Math.random() * brushSize/3) + 1;
                g2d.fillOval(point.getX() + offsetX, point.getY() + offsetY, size, size);
            }
        }
    }
}
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class HSLColorPicker extends JPanel {
    private float hue = 0f, sat = 1f, bri = 1f;
    private RoundedPanel preview;
    private ColorSelectionListener colorListener;
    private Color selectedColor = Color.RED;

    private MinimalBar sizeBar, opacityBar;
    private int brushSize = 10;
    private float opacity = 1f;

    // Mode buttons
    private ModeButton[] modeButtons = new ModeButton[4];
    private int activeMode = 0;

    public interface ColorSelectionListener {
        void colorSelected(Color color);
        void brushSizeChanged(int size);
        void opacityChanged(float opacity);
        void brushTypeChanged(int brushType);
    }

    public HSLColorPicker() {
        setLayout(null);
        setPreferredSize(new Dimension(320, 500));
        setBackground(new Color(217, 217, 217));

        // Color area
        ColorBox box = new ColorBox();
        box.setBounds(15, 20, 200, 200);
        add(box);

        // Preview
        preview = new RoundedPanel(25);
        preview.setBounds(15, 230, 230, 25);
        preview.setBackground(selectedColor);
        add(preview);

        // Hue bar
        HueBar hueBar = new HueBar();
        hueBar.setBounds(225, 20, 20, 200);
        add(hueBar);

        // Brush size label
        JLabel sizeLabel = new JLabel("Size");
        sizeLabel.setBounds(30, 270, 100, 20);
        add(sizeLabel);

        sizeBar = new MinimalBar();
        sizeBar.setBounds(30, 290, 205, 25);
        sizeBar.setValue(0.1f); // Default size
        add(sizeBar);

        // Opacity label
        JLabel opacityLabel = new JLabel("Opacity");
        opacityLabel.setBounds(30, 325, 100, 20);
        add(opacityLabel);

        opacityBar = new MinimalBar();
        opacityBar.setBounds(30, 345, 205, 25);
        opacityBar.setValue(1f); // Full opacity by default
        add(opacityBar);

        // Mode buttons
        String[] names = {"A", "N", "M", "K"};
        int startX = 26;
        for (int i = 0; i < 4; i++) {
            ModeButton btn = new ModeButton(names[i]);
            btn.setBounds(startX + (i * 54), 385, 47, 47);
            final int index = i;
            btn.addActionListener(e -> setActiveMode(index));
            add(btn);
            modeButtons[i] = btn;
        }
        setActiveMode(0); // Default to first mode

        // Event Handlers
        hueBar.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) { updateHue(e, hueBar, box); }
        });
        hueBar.addMouseMotionListener(new MouseAdapter() {
            public void mouseDragged(MouseEvent e) { updateHue(e, hueBar, box); }
        });

        box.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) { updateColorBox(e, box); }
        });
        box.addMouseMotionListener(new MouseAdapter() {
            public void mouseDragged(MouseEvent e) { updateColorBox(e, box); }
        });

        sizeBar.setOnChange(() -> {
            brushSize = (int) (sizeBar.getValue() * 100);
            if (brushSize < 1) brushSize = 1;
            if (colorListener != null) {
                colorListener.brushSizeChanged(brushSize);
            }
        });

        opacityBar.setOnChange(() -> {
            opacity = opacityBar.getValue();
            updateColor();
            if (colorListener != null) {
                colorListener.opacityChanged(opacity);
            }
        });
    }

    private void setActiveMode(int index) {
        activeMode = index;
        for (int i = 0; i < modeButtons.length; i++) {
            modeButtons[i].setActive(i == index);
        }
        if (colorListener != null) {
            colorListener.brushTypeChanged(index);
        }
    }

    // Background Rendering
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Background panel for settings area
        g2.setColor(new Color(174, 174, 174));
        g2.fillRoundRect(15, 260, 230, 190, 25, 25);
    }

    // Color updates
    private void updateHue(MouseEvent e, HueBar hueBar, ColorBox box) {
        hue = (float) e.getY() / hueBar.getHeight();
        hue = Math.max(0f, Math.min(1f, hue));
        box.setHue(hue);
        updateColor();
    }

    private void updateColorBox(MouseEvent e, ColorBox box) {
        sat = (float) e.getX() / box.getWidth();
        bri = 1f - (float) e.getY() / box.getHeight();
        sat = Math.max(0f, Math.min(1f, sat));
        bri = Math.max(0f, Math.min(1f, bri));
        updateColor();
    }

    private void updateColor() {
        Color base = Color.getHSBColor(hue, sat, bri);
        selectedColor = new Color(base.getRed(), base.getGreen(), base.getBlue(), (int)(opacity * 255));
        preview.setBackground(base);
        if (colorListener != null) {
            colorListener.colorSelected(selectedColor);
        }
    }

    public Color getSelectedColor() { return selectedColor; }
    public int getBrushSize() { return brushSize; }
    public float getOpacity() { return opacity; }
    public int getActiveBrushType() { return activeMode; }

    public void setColorSelectionListener(ColorSelectionListener listener) {
        this.colorListener = listener;
    }

    public void setBrushSize(int size) {
        this.brushSize = size;
        if (sizeBar != null) {
            sizeBar.setValue(size / 100.0f);
        }
    }

    public void setOpacity(float opacity) {
        this.opacity = opacity;
        if (opacityBar != null) {
            opacityBar.setValue(opacity);
        }
        updateColor();
    }

    // INNER CLASSES

    private class ModeButton extends JButton {
        private boolean active = false;

        public ModeButton(String text) {
            super(text);
            setFocusPainted(false);
            setBorderPainted(false);
            setContentAreaFilled(false);
            setFont(new Font("SansSerif", Font.PLAIN, 11));
            setForeground(Color.BLACK);
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        }

        public void setActive(boolean active) {
            this.active = active;
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            if (active)
                g2.setColor(new Color(0, 187, 255));
            else
                g2.setColor(Color.WHITE);

            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 15, 15);

            // Text
            g2.setColor(Color.BLACK);
            FontMetrics fm = g2.getFontMetrics();
            int textX = (getWidth() - fm.stringWidth(getText())) / 2;
            int textY = (getHeight() + fm.getAscent()) / 2 - 2;
            g2.drawString(getText(), textX, textY);
        }
    }

    private class HueBar extends JPanel {
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            for (int y = 0; y < getHeight(); y++) {
                float h = (float) y / getHeight();
                g.setColor(Color.getHSBColor(h, 1f, 1f));
                g.drawLine(0, y, getWidth(), y);
            }
        }
    }

    private class ColorBox extends JPanel {
        private float hueValue = 0f;
        public void setHue(float h) { hueValue = h; repaint(); }

        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            for (int x = 0; x < getWidth(); x++) {
                for (int y = 0; y < getHeight(); y++) {
                    float s = (float) x / getWidth();
                    float b = 1f - (float) y / getHeight();
                    g.setColor(Color.getHSBColor(hueValue, s, b));
                    g.drawLine(x, y, x, y);
                }
            }
        }
    }

    private class RoundedPanel extends JPanel {
        private int radius;

        public RoundedPanel(int radius) {
            this.radius = radius;
            setOpaque(false);
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(getBackground());
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), radius, radius);
        }
    }
}

// MinimalBar class (you'll need to implement this or use the one from your code)
class MinimalBar extends JPanel {
    private float value = 0f;
    private Runnable onChange;

    public MinimalBar() {
        setPreferredSize(new Dimension(200, 25));
        addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) { updateValue(e); }
        });
        addMouseMotionListener(new MouseAdapter() {
            public void mouseDragged(MouseEvent e) { updateValue(e); }
        });
    }

    private void updateValue(MouseEvent e) {
        value = (float) e.getX() / getWidth();
        value = Math.max(0f, Math.min(1f, value));
        repaint();
        if (onChange != null) onChange.run();
    }

    public void setValue(float value) {
        this.value = Math.max(0f, Math.min(1f, value));
        repaint();
    }

    public float getValue() { return value; }
    public void setOnChange(Runnable listener) { this.onChange = listener; }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Background
        g2.setColor(new Color(200, 200, 200));
        g2.fillRoundRect(0, 0, getWidth(), getHeight(), 12, 12);

        // Fill
        g2.setColor(new Color(100, 100, 100));
        g2.fillRoundRect(0, 0, (int)(getWidth() * value), getHeight(), 12, 12);

        // Border
        g2.setColor(new Color(150, 150, 150));
        g2.drawRoundRect(0, 0, getWidth()-1, getHeight()-1, 12, 12);
    }
}
import java.awt.*;

class ColorPoint {
    private int x, y;
    private Color color;
    private int strokeSize;
    private float opacity;

    public ColorPoint(int x, int y, Color color, int strokeSize, float opacity) {
        this.x = x;
        this.y = y;
        this.color = color;
        this.strokeSize = strokeSize;
        this.opacity = opacity;
    }

    public int getX() { return x; }
    public int getY() { return y; }
    public Color getColor() { return color; }
    public int getStrokeSize() { return strokeSize; }
    public float getOpacity() { return opacity; }
}